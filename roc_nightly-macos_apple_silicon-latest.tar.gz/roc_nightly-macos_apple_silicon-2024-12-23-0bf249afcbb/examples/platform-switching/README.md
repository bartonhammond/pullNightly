
# Platform switching

To run, `cd` into this directory and run this in your terminal:

```bash
roc --build-host --suppress-build-host-warning rocLovesC.roc
```

## About these examples

They use a very simple [platform](https://www.roc-lang.org/platforms) which does nothing more than printing the string you give it.

If you want to start building your own platforms, these are some very simple example platforms to use as starting points.
